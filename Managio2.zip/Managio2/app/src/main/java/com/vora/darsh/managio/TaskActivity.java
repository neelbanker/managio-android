package com.vora.darsh.managio;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class TaskActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private List<Task_raw> taskList;
    private TaskAdapter taskAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task);

        String tasks_raw = getIntent().getStringExtra("tasks");
        String[] tasks = tasks_raw.split(";;");


        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);

        taskList = new ArrayList<>();

        for (int i = 0;i <tasks.length;i++){
            String[] task = tasks[i].split(";");

            String title = task[1];

            String details = task[2];

            String startDate = task[3];

            String endDate = task[4];

            String link = task[5];

            String status = task[0];

            taskList.add(new Task_raw(title,details,startDate,endDate,link,status));

        }
//        taskList.add(new Task_raw("task1","wdwfwefwfwefwfwff","31/01/1998","31/02/1998"));
//        taskList.add(new Task_raw("task2","wdwfwefwfwefwfwff","31/01/1998","31/02/1998"));
//        taskList.add(new Task_raw("task3","wdwfwefwfwefwfwff","31/01/1998","31/02/1998"));
//        taskList.add(new Task_raw("task4","wdwfwefwfwefwfwff","31/01/1998","31/02/1998"));
//        taskList.add(new Task_raw("task5","wdwfwefwfwefwfwff","31/01/1998","31/02/1998"));
//        taskList.add(new Task_raw("task6","wdwfwefwfwefwfwff","31/01/1998","31/02/1998"));
//        taskList.add(new Task_raw("task7","wdwfwefwfwefwfwff","31/01/1998","31/02/1998"));
//        taskList.add(new Task_raw("task8","wdwfwefwfwefwfwff","31/01/1998","31/02/1998"));
//        taskList.add(new Task_raw("task9","wdwfwefwfwefwfwff","31/01/1998","31/02/1998"));
//        taskList.add(new Task_raw("task10","wdwfwefwfwefwfwff","31/01/1998","31/02/1998"));
        taskAdapter = new TaskAdapter(this, taskList);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(taskAdapter);
    }
}
