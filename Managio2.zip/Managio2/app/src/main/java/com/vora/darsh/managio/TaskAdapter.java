package com.vora.darsh.managio;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.MyViewHolder> {

    private Context mContext;
    private List<Task_raw> taskList;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView title, description,startDate,endDate,status,link;
        public Button taskButton;

        public MyViewHolder(View view) {
            super(view);
            title = view.findViewById(R.id.titleTask);

            description = view.findViewById(R.id.descriptionTask);
            startDate = view.findViewById(R.id.startDateTask);
            endDate = view.findViewById(R.id.endDateTask);
            taskButton = view.findViewById(R.id.taskButton);
            status = view.findViewById(R.id.statusTask);
            link = view.findViewById(R.id.linkTask);
        }
    }

    public TaskAdapter(Context mContext, List<Task_raw> taskList) {
        this.mContext = mContext;
        this.taskList = taskList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View itemView = LayoutInflater.from(mContext)
                .inflate(R.layout.task_raw, null);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder,int i) {
        final Task_raw task = taskList.get(i);

        holder.title.setText(task.getTitle());
        holder.description.setText(task.getDetails());
        holder.startDate.setText(task.getStartDate());
        holder.endDate.setText(task.getEndDate());
        holder.status.setText(task.getStatus());

        if(task.getStatus().equals("Pending") || task.getStatus().equals("Stop")){
            holder.taskButton.setText("Start");
        }else {
            holder.taskButton.setText("Stop");
        }

        holder.taskButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(mContext,"Button clicked :"+ holder.getAdapterPosition(),Toast.LENGTH_SHORT).show();
            }
        });

        holder.link.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(mContext,"Downloading Attachment"+ holder.getAdapterPosition(),Toast.LENGTH_SHORT).show();
                mContext.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(task.getLink())));
            }
        });
    }

    @Override
    public int getItemCount() {
        return taskList.size();
    }
}
